﻿namespace opengl
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.openGLControl1 = new SharpGL.OpenGLControl();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.視角ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_front = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_right = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_up = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_iso = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openGLControl1
            // 
            this.openGLControl1.DrawFPS = true;
            this.openGLControl1.FrameRate = 60;
            this.openGLControl1.Location = new System.Drawing.Point(12, 38);
            this.openGLControl1.Name = "openGLControl1";
            this.openGLControl1.OpenGLVersion = SharpGL.Version.OpenGLVersion.OpenGL2_1;
            this.openGLControl1.RenderContextType = SharpGL.RenderContextType.DIBSection;
            this.openGLControl1.RenderTrigger = SharpGL.RenderTrigger.TimerBased;
            this.openGLControl1.Size = new System.Drawing.Size(481, 400);
            this.openGLControl1.TabIndex = 0;
            this.openGLControl1.OpenGLInitialized += new System.EventHandler(this.openGLControl1_OpenGLInitialized);
            this.openGLControl1.OpenGLDraw += new SharpGL.RenderEventHandler(this.openGLControl1_OpenGLDraw);
            this.openGLControl1.Resized += new System.EventHandler(this.openGLControl1_Resized);
            this.openGLControl1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.openGLControl1_MouseDown);
            this.openGLControl1.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.openGLControl1_MouseWheel);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.視角ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 視角ToolStripMenuItem
            // 
            this.視角ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi_front,
            this.tsmi_right,
            this.tsmi_up,
            this.tsmi_iso});
            this.視角ToolStripMenuItem.Name = "視角ToolStripMenuItem";
            this.視角ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.視角ToolStripMenuItem.Text = "視角";
            // 
            // tsmi_front
            // 
            this.tsmi_front.Name = "tsmi_front";
            this.tsmi_front.Size = new System.Drawing.Size(98, 22);
            this.tsmi_front.Text = "前";
            this.tsmi_front.Click += new System.EventHandler(this.tsmi_front_Click);
            // 
            // tsmi_right
            // 
            this.tsmi_right.Name = "tsmi_right";
            this.tsmi_right.Size = new System.Drawing.Size(98, 22);
            this.tsmi_right.Text = "右";
            this.tsmi_right.Click += new System.EventHandler(this.tsmi_right_Click);
            // 
            // tsmi_up
            // 
            this.tsmi_up.Name = "tsmi_up";
            this.tsmi_up.Size = new System.Drawing.Size(98, 22);
            this.tsmi_up.Text = "上";
            this.tsmi_up.Click += new System.EventHandler(this.tsmi_up_Click);
            // 
            // tsmi_iso
            // 
            this.tsmi_iso.Name = "tsmi_iso";
            this.tsmi_iso.Size = new System.Drawing.Size(98, 22);
            this.tsmi_iso.Text = "等角";
            this.tsmi_iso.Click += new System.EventHandler(this.tsmi_iso_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(548, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(548, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "label1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(548, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.openGLControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SharpGL.OpenGLControl openGLControl1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 視角ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmi_front;
        private System.Windows.Forms.ToolStripMenuItem tsmi_right;
        private System.Windows.Forms.ToolStripMenuItem tsmi_up;
        private System.Windows.Forms.ToolStripMenuItem tsmi_iso;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

