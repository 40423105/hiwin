﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int Robot_id;
        int op;
        int space;
        int index;
        int dir;
        int move_status;
        double[] pos = new double[] {0,0,0,0,0,0};

        public static void EventFun(UInt16 cmd, UInt16 rlt, ref UInt16 Msg, int len)
        {
            Console.WriteLine("Command: " + cmd + " Resault: " + rlt);
        }
        private static SDKHrobot.HRobot.CallBackFun callback = new SDKHrobot.HRobot.CallBackFun(EventFun);

        public Form1()
        {
            InitializeComponent();
        }

        private void get_pos()
        {
            SDKHrobot.HRobot.get_current_joint(Robot_id, pos);
            a1_degree.Text = pos[0].ToString();
            a2_degree.Text = pos[1].ToString();
            a3_degree.Text = pos[2].ToString();
            a4_degree.Text = pos[3].ToString();
            a5_degree.Text = pos[4].ToString();
            a6_degree.Text = pos[5].ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void getToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder SDK_ver = new StringBuilder();
            SDKHrobot.HRobot.get_hrsdk_version(SDK_ver);
            label_sdk.Text = SDK_ver.ToString();
        }

        private void connectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string ip = "127.0.0.1";
            int level = 1;
            Robot_id = SDKHrobot.HRobot.open_connection(ip, level, callback);
            if(Robot_id == 0 || Robot_id == 1 || Robot_id == 3)
                label_cs.Text = "裝置" + Robot_id + "已連線"; 
        }

        private void 自動模式ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            op = SDKHrobot.HRobot.set_operation_mode(Robot_id, 1);
            label_status.Text = op.ToString();
        }

        private void 手動模式ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            op = SDKHrobot.HRobot.set_operation_mode(Robot_id, 0);
            label_status.Text = op.ToString();
        }

        private void jog_home_Click(object sender, EventArgs e)
        {
            SDKHrobot.HRobot.jog_home(Robot_id);
            get_pos();
        }

        private void jog_a1_p_MouseDown(object sender, MouseEventArgs e)
        {
            space = 1;
            index = 0;
            dir = 1;

            move_status = SDKHrobot.HRobot.jog(Robot_id, space, index, dir);
            label_status.Text = move_status.ToString();

            get_pos();
        }

        private void jog_a1_p_MouseUp(object sender, MouseEventArgs e)
        {
            SDKHrobot.HRobot.jog_stop(Robot_id);
        }

        private void jog_a1_n_MouseDown(object sender, MouseEventArgs e)
        {
            space = 1;
            index = 0;
            dir = -1;

            move_status = SDKHrobot.HRobot.jog(Robot_id, space, index, dir);
            label_status.Text = move_status.ToString();
            get_pos();
        }

        private void jog_a1_n_MouseUp(object sender, MouseEventArgs e)
        {
            SDKHrobot.HRobot.jog_stop(Robot_id);
        }

        private void jog_a2_p_MouseDown(object sender, MouseEventArgs e)
        {
            space = 1;
            index = 1;
            dir = 1;

            move_status = SDKHrobot.HRobot.jog(Robot_id, space, index, dir);
            label_status.Text = move_status.ToString();
            get_pos();
        }

        private void jog_a2_p_MouseUp(object sender, MouseEventArgs e)
        {
            SDKHrobot.HRobot.jog_stop(Robot_id);
        }

        private void jog_a2_n_MouseDown(object sender, MouseEventArgs e)
        {
            space = 1;
            index = 1;
            dir = -1;

            move_status = SDKHrobot.HRobot.jog(Robot_id, space, index, dir);
            label_status.Text = move_status.ToString();
            get_pos();
        }

        private void jog_a2_n_MouseUp(object sender, MouseEventArgs e)
        {
            SDKHrobot.HRobot.jog_stop(Robot_id);
        }

        private void jog_a3_p_MouseDown(object sender, MouseEventArgs e)
        {
            space = 1;
            index = 2;
            dir = 1;

            move_status = SDKHrobot.HRobot.jog(Robot_id, space, index, dir);
            label_status.Text = move_status.ToString();
            get_pos();
        }

        private void jog_a3_p_MouseUp(object sender, MouseEventArgs e)
        {
            SDKHrobot.HRobot.jog_stop(Robot_id);
        }

        private void jog_a3_n_MouseDown(object sender, MouseEventArgs e)
        {
            space = 1;
            index = 2;
            dir = -1;

            move_status = SDKHrobot.HRobot.jog(Robot_id, space, index, dir);
            label_status.Text = move_status.ToString();
            get_pos();
        }

        private void jog_a3_n_MouseUp(object sender, MouseEventArgs e)
        {
            SDKHrobot.HRobot.jog_stop(Robot_id);
        }

        private void jog_a4_p_MouseDown(object sender, MouseEventArgs e)
        {
            space = 1;
            index = 3;
            dir = 1;

            move_status = SDKHrobot.HRobot.jog(Robot_id, space, index, dir);
            label_status.Text = move_status.ToString();
            get_pos();
        }

        private void jog_a4_p_MouseUp(object sender, MouseEventArgs e)
        {
            SDKHrobot.HRobot.jog_stop(Robot_id);
        }

        private void jog_a4_n_MouseDown(object sender, MouseEventArgs e)
        {
            space = 1;
            index = 3;
            dir = -1;

            move_status = SDKHrobot.HRobot.jog(Robot_id, space, index, dir);
            label_status.Text = move_status.ToString();
            get_pos();
        }

        private void jog_a4_n_MouseUp(object sender, MouseEventArgs e)
        {
            SDKHrobot.HRobot.jog_stop(Robot_id);
        }

        private void jog_a5_p_MouseDown(object sender, MouseEventArgs e)
        {
            space = 1;
            index = 4;
            dir = 1;

            move_status = SDKHrobot.HRobot.jog(Robot_id, space, index, dir);
            label_status.Text = move_status.ToString();
            get_pos();
        }

        private void jog_a5_p_MouseUp(object sender, MouseEventArgs e)
        {
            SDKHrobot.HRobot.jog_stop(Robot_id);
        }

        private void jog_a5_n_MouseDown(object sender, MouseEventArgs e)
        {
            space = 1;
            index = 4;
            dir = -1;

            move_status = SDKHrobot.HRobot.jog(Robot_id, space, index, dir);
            label_status.Text = move_status.ToString();
            get_pos();
        }

        private void jog_a5_n_MouseUp(object sender, MouseEventArgs e)
        {
            SDKHrobot.HRobot.jog_stop(Robot_id);
        }

        private void jog_a6_p_MouseDown(object sender, MouseEventArgs e)
        {
            space = 1;
            index = 5;
            dir = 1;

            move_status = SDKHrobot.HRobot.jog(Robot_id, space, index, dir);
            label_status.Text = move_status.ToString();
            get_pos();
        }

        private void jog_a6_p_MouseUp(object sender, MouseEventArgs e)
        {
            SDKHrobot.HRobot.jog_stop(Robot_id);
        }

        private void jog_a6_n_MouseDown(object sender, MouseEventArgs e)
        {
            space = 1;
            index = 5;
            dir = -1;

            move_status = SDKHrobot.HRobot.jog(Robot_id, space, index, dir);
            label_status.Text = move_status.ToString();
            get_pos();
        }

        private void jog_a6_n_MouseUp(object sender, MouseEventArgs e)
        {
            SDKHrobot.HRobot.jog_stop(Robot_id);
        }

        private void disconnectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SDKHrobot.HRobot.disconnect(Robot_id);
            label_cs.Text = "已斷線";
        }


    }
}
