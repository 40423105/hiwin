﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.功能ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.getToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.模式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.自動模式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.手動模式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label_status = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label_cs = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label_sdk = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.jog_a6_p = new System.Windows.Forms.Button();
            this.jog_a6_n = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.jog_a5_p = new System.Windows.Forms.Button();
            this.jog_a5_n = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.jog_a4_p = new System.Windows.Forms.Button();
            this.jog_a4_n = new System.Windows.Forms.Button();
            this.jog_a3_p = new System.Windows.Forms.Button();
            this.jog_a3_n = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.jog_a2_p = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.jog_a2_n = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.jog_home = new System.Windows.Forms.Button();
            this.jog_a1_p = new System.Windows.Forms.Button();
            this.jog_a1_n = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.disconnectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.a1_degree = new System.Windows.Forms.Label();
            this.a2_degree = new System.Windows.Forms.Label();
            this.a3_degree = new System.Windows.Forms.Label();
            this.a4_degree = new System.Windows.Forms.Label();
            this.a5_degree = new System.Windows.Forms.Label();
            this.a6_degree = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.功能ToolStripMenuItem,
            this.模式ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 功能ToolStripMenuItem
            // 
            this.功能ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.getToolStripMenuItem,
            this.connectToolStripMenuItem,
            this.disconnectToolStripMenuItem});
            this.功能ToolStripMenuItem.Name = "功能ToolStripMenuItem";
            this.功能ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.功能ToolStripMenuItem.Text = "功能";
            // 
            // getToolStripMenuItem
            // 
            this.getToolStripMenuItem.Name = "getToolStripMenuItem";
            this.getToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.getToolStripMenuItem.Text = "Get_SDK_Version";
            this.getToolStripMenuItem.Click += new System.EventHandler(this.getToolStripMenuItem_Click);
            // 
            // connectToolStripMenuItem
            // 
            this.connectToolStripMenuItem.Name = "connectToolStripMenuItem";
            this.connectToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.connectToolStripMenuItem.Text = "Connect";
            this.connectToolStripMenuItem.Click += new System.EventHandler(this.connectToolStripMenuItem_Click);
            // 
            // 模式ToolStripMenuItem
            // 
            this.模式ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.自動模式ToolStripMenuItem,
            this.手動模式ToolStripMenuItem});
            this.模式ToolStripMenuItem.Name = "模式ToolStripMenuItem";
            this.模式ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.模式ToolStripMenuItem.Text = "模式";
            // 
            // 自動模式ToolStripMenuItem
            // 
            this.自動模式ToolStripMenuItem.Name = "自動模式ToolStripMenuItem";
            this.自動模式ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.自動模式ToolStripMenuItem.Text = "自動模式";
            this.自動模式ToolStripMenuItem.Click += new System.EventHandler(this.自動模式ToolStripMenuItem_Click);
            // 
            // 手動模式ToolStripMenuItem
            // 
            this.手動模式ToolStripMenuItem.Name = "手動模式ToolStripMenuItem";
            this.手動模式ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.手動模式ToolStripMenuItem.Text = "手動模式";
            this.手動模式ToolStripMenuItem.Click += new System.EventHandler(this.手動模式ToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label_status);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label_cs);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label_sdk);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(293, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(285, 157);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "狀態區";
            // 
            // label_status
            // 
            this.label_status.AutoSize = true;
            this.label_status.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_status.Location = new System.Drawing.Point(129, 103);
            this.label_status.Name = "label_status";
            this.label_status.Size = new System.Drawing.Size(18, 19);
            this.label_status.TabIndex = 5;
            this.label_status.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "狀態碼:";
            // 
            // label_cs
            // 
            this.label_cs.AutoSize = true;
            this.label_cs.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_cs.Location = new System.Drawing.Point(129, 66);
            this.label_cs.Name = "label_cs";
            this.label_cs.Size = new System.Drawing.Size(18, 19);
            this.label_cs.TabIndex = 3;
            this.label_cs.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "連線狀態:";
            // 
            // label_sdk
            // 
            this.label_sdk.AutoSize = true;
            this.label_sdk.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_sdk.Location = new System.Drawing.Point(129, 30);
            this.label_sdk.Name = "label_sdk";
            this.label_sdk.Size = new System.Drawing.Size(18, 19);
            this.label_sdk.TabIndex = 1;
            this.label_sdk.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(7, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "SDK_Version:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.jog_a6_p);
            this.groupBox2.Controls.Add(this.jog_a6_n);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.jog_a5_p);
            this.groupBox2.Controls.Add(this.jog_a5_n);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.jog_a4_p);
            this.groupBox2.Controls.Add(this.jog_a4_n);
            this.groupBox2.Controls.Add(this.jog_a3_p);
            this.groupBox2.Controls.Add(this.jog_a3_n);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.jog_a2_p);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.jog_a2_n);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.jog_home);
            this.groupBox2.Controls.Add(this.jog_a1_p);
            this.groupBox2.Controls.Add(this.jog_a1_n);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox2.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox2.Location = new System.Drawing.Point(13, 37);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(255, 285);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "操作區";
            // 
            // jog_a6_p
            // 
            this.jog_a6_p.BackColor = System.Drawing.Color.Red;
            this.jog_a6_p.Location = new System.Drawing.Point(140, 210);
            this.jog_a6_p.Name = "jog_a6_p";
            this.jog_a6_p.Size = new System.Drawing.Size(53, 30);
            this.jog_a6_p.TabIndex = 13;
            this.jog_a6_p.Text = "+";
            this.jog_a6_p.UseVisualStyleBackColor = false;
            this.jog_a6_p.MouseDown += new System.Windows.Forms.MouseEventHandler(this.jog_a6_p_MouseDown);
            this.jog_a6_p.MouseUp += new System.Windows.Forms.MouseEventHandler(this.jog_a6_p_MouseUp);
            // 
            // jog_a6_n
            // 
            this.jog_a6_n.BackColor = System.Drawing.Color.Lime;
            this.jog_a6_n.Location = new System.Drawing.Point(63, 210);
            this.jog_a6_n.Name = "jog_a6_n";
            this.jog_a6_n.Size = new System.Drawing.Size(53, 30);
            this.jog_a6_n.TabIndex = 12;
            this.jog_a6_n.Text = "-";
            this.jog_a6_n.UseVisualStyleBackColor = false;
            this.jog_a6_n.MouseDown += new System.Windows.Forms.MouseEventHandler(this.jog_a6_n_MouseDown);
            this.jog_a6_n.MouseUp += new System.Windows.Forms.MouseEventHandler(this.jog_a6_n_MouseUp);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(6, 218);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 15);
            this.label9.TabIndex = 11;
            this.label9.Text = "A6";
            // 
            // jog_a5_p
            // 
            this.jog_a5_p.BackColor = System.Drawing.Color.Red;
            this.jog_a5_p.Location = new System.Drawing.Point(140, 174);
            this.jog_a5_p.Name = "jog_a5_p";
            this.jog_a5_p.Size = new System.Drawing.Size(53, 30);
            this.jog_a5_p.TabIndex = 10;
            this.jog_a5_p.Text = "+";
            this.jog_a5_p.UseVisualStyleBackColor = false;
            this.jog_a5_p.MouseDown += new System.Windows.Forms.MouseEventHandler(this.jog_a5_p_MouseDown);
            this.jog_a5_p.MouseUp += new System.Windows.Forms.MouseEventHandler(this.jog_a5_p_MouseUp);
            // 
            // jog_a5_n
            // 
            this.jog_a5_n.BackColor = System.Drawing.Color.Lime;
            this.jog_a5_n.Location = new System.Drawing.Point(63, 174);
            this.jog_a5_n.Name = "jog_a5_n";
            this.jog_a5_n.Size = new System.Drawing.Size(53, 30);
            this.jog_a5_n.TabIndex = 9;
            this.jog_a5_n.Text = "-";
            this.jog_a5_n.UseVisualStyleBackColor = false;
            this.jog_a5_n.MouseDown += new System.Windows.Forms.MouseEventHandler(this.jog_a5_n_MouseDown);
            this.jog_a5_n.MouseUp += new System.Windows.Forms.MouseEventHandler(this.jog_a5_n_MouseUp);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(6, 182);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 15);
            this.label8.TabIndex = 8;
            this.label8.Text = "A5";
            // 
            // jog_a4_p
            // 
            this.jog_a4_p.BackColor = System.Drawing.Color.Red;
            this.jog_a4_p.Location = new System.Drawing.Point(140, 138);
            this.jog_a4_p.Name = "jog_a4_p";
            this.jog_a4_p.Size = new System.Drawing.Size(53, 30);
            this.jog_a4_p.TabIndex = 7;
            this.jog_a4_p.Text = "+";
            this.jog_a4_p.UseVisualStyleBackColor = false;
            this.jog_a4_p.MouseDown += new System.Windows.Forms.MouseEventHandler(this.jog_a4_p_MouseDown);
            this.jog_a4_p.MouseUp += new System.Windows.Forms.MouseEventHandler(this.jog_a4_p_MouseUp);
            // 
            // jog_a4_n
            // 
            this.jog_a4_n.BackColor = System.Drawing.Color.Lime;
            this.jog_a4_n.Location = new System.Drawing.Point(63, 138);
            this.jog_a4_n.Name = "jog_a4_n";
            this.jog_a4_n.Size = new System.Drawing.Size(53, 30);
            this.jog_a4_n.TabIndex = 6;
            this.jog_a4_n.Text = "-";
            this.jog_a4_n.UseVisualStyleBackColor = false;
            this.jog_a4_n.MouseDown += new System.Windows.Forms.MouseEventHandler(this.jog_a4_n_MouseDown);
            this.jog_a4_n.MouseUp += new System.Windows.Forms.MouseEventHandler(this.jog_a4_n_MouseUp);
            // 
            // jog_a3_p
            // 
            this.jog_a3_p.BackColor = System.Drawing.Color.Red;
            this.jog_a3_p.Location = new System.Drawing.Point(140, 102);
            this.jog_a3_p.Name = "jog_a3_p";
            this.jog_a3_p.Size = new System.Drawing.Size(53, 30);
            this.jog_a3_p.TabIndex = 7;
            this.jog_a3_p.Text = "+";
            this.jog_a3_p.UseVisualStyleBackColor = false;
            this.jog_a3_p.MouseDown += new System.Windows.Forms.MouseEventHandler(this.jog_a3_p_MouseDown);
            this.jog_a3_p.MouseUp += new System.Windows.Forms.MouseEventHandler(this.jog_a3_p_MouseUp);
            // 
            // jog_a3_n
            // 
            this.jog_a3_n.BackColor = System.Drawing.Color.Lime;
            this.jog_a3_n.Location = new System.Drawing.Point(63, 102);
            this.jog_a3_n.Name = "jog_a3_n";
            this.jog_a3_n.Size = new System.Drawing.Size(53, 30);
            this.jog_a3_n.TabIndex = 6;
            this.jog_a3_n.Text = "-";
            this.jog_a3_n.UseVisualStyleBackColor = false;
            this.jog_a3_n.MouseDown += new System.Windows.Forms.MouseEventHandler(this.jog_a3_n_MouseDown);
            this.jog_a3_n.MouseUp += new System.Windows.Forms.MouseEventHandler(this.jog_a3_n_MouseUp);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(6, 146);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 15);
            this.label7.TabIndex = 5;
            this.label7.Text = "A4";
            // 
            // jog_a2_p
            // 
            this.jog_a2_p.BackColor = System.Drawing.Color.Red;
            this.jog_a2_p.Location = new System.Drawing.Point(140, 66);
            this.jog_a2_p.Name = "jog_a2_p";
            this.jog_a2_p.Size = new System.Drawing.Size(53, 30);
            this.jog_a2_p.TabIndex = 7;
            this.jog_a2_p.Text = "+";
            this.jog_a2_p.UseVisualStyleBackColor = false;
            this.jog_a2_p.MouseDown += new System.Windows.Forms.MouseEventHandler(this.jog_a2_p_MouseDown);
            this.jog_a2_p.MouseUp += new System.Windows.Forms.MouseEventHandler(this.jog_a2_p_MouseUp);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(6, 110);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "A3";
            // 
            // jog_a2_n
            // 
            this.jog_a2_n.BackColor = System.Drawing.Color.Lime;
            this.jog_a2_n.Location = new System.Drawing.Point(63, 66);
            this.jog_a2_n.Name = "jog_a2_n";
            this.jog_a2_n.Size = new System.Drawing.Size(53, 30);
            this.jog_a2_n.TabIndex = 6;
            this.jog_a2_n.Text = "-";
            this.jog_a2_n.UseVisualStyleBackColor = false;
            this.jog_a2_n.MouseDown += new System.Windows.Forms.MouseEventHandler(this.jog_a2_n_MouseDown);
            this.jog_a2_n.MouseUp += new System.Windows.Forms.MouseEventHandler(this.jog_a2_n_MouseUp);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(6, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "A2";
            // 
            // jog_home
            // 
            this.jog_home.AllowDrop = true;
            this.jog_home.Location = new System.Drawing.Point(6, 246);
            this.jog_home.Name = "jog_home";
            this.jog_home.Size = new System.Drawing.Size(75, 32);
            this.jog_home.TabIndex = 4;
            this.jog_home.Text = "HOME";
            this.jog_home.UseVisualStyleBackColor = true;
            this.jog_home.Click += new System.EventHandler(this.jog_home_Click);
            // 
            // jog_a1_p
            // 
            this.jog_a1_p.BackColor = System.Drawing.Color.Red;
            this.jog_a1_p.Location = new System.Drawing.Point(140, 30);
            this.jog_a1_p.Name = "jog_a1_p";
            this.jog_a1_p.Size = new System.Drawing.Size(53, 30);
            this.jog_a1_p.TabIndex = 3;
            this.jog_a1_p.Text = "+";
            this.jog_a1_p.UseVisualStyleBackColor = false;
            this.jog_a1_p.MouseDown += new System.Windows.Forms.MouseEventHandler(this.jog_a1_p_MouseDown);
            this.jog_a1_p.MouseUp += new System.Windows.Forms.MouseEventHandler(this.jog_a1_p_MouseUp);
            // 
            // jog_a1_n
            // 
            this.jog_a1_n.BackColor = System.Drawing.Color.Lime;
            this.jog_a1_n.Location = new System.Drawing.Point(63, 30);
            this.jog_a1_n.Name = "jog_a1_n";
            this.jog_a1_n.Size = new System.Drawing.Size(53, 30);
            this.jog_a1_n.TabIndex = 2;
            this.jog_a1_n.Text = "-";
            this.jog_a1_n.UseVisualStyleBackColor = false;
            this.jog_a1_n.MouseDown += new System.Windows.Forms.MouseEventHandler(this.jog_a1_n_MouseDown);
            this.jog_a1_n.MouseUp += new System.Windows.Forms.MouseEventHandler(this.jog_a1_n_MouseUp);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(6, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "A1";
            // 
            // disconnectToolStripMenuItem
            // 
            this.disconnectToolStripMenuItem.Name = "disconnectToolStripMenuItem";
            this.disconnectToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.disconnectToolStripMenuItem.Text = "Disconnect";
            this.disconnectToolStripMenuItem.Click += new System.EventHandler(this.disconnectToolStripMenuItem_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.a6_degree);
            this.groupBox3.Controls.Add(this.a5_degree);
            this.groupBox3.Controls.Add(this.a4_degree);
            this.groupBox3.Controls.Add(this.a3_degree);
            this.groupBox3.Controls.Add(this.a2_degree);
            this.groupBox3.Controls.Add(this.a1_degree);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox3.Location = new System.Drawing.Point(13, 329);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(267, 109);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "座標(度)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(6, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(28, 15);
            this.label10.TabIndex = 2;
            this.label10.Text = "A1:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(87, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(28, 15);
            this.label11.TabIndex = 2;
            this.label11.Text = "A2:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(172, 32);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(28, 15);
            this.label12.TabIndex = 2;
            this.label12.Text = "A3:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(6, 77);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(28, 15);
            this.label13.TabIndex = 2;
            this.label13.Text = "A4:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(87, 77);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(28, 15);
            this.label14.TabIndex = 2;
            this.label14.Text = "A5:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(172, 77);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(28, 15);
            this.label15.TabIndex = 2;
            this.label15.Text = "A6:";
            // 
            // a1_degree
            // 
            this.a1_degree.AutoSize = true;
            this.a1_degree.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.a1_degree.Location = new System.Drawing.Point(34, 31);
            this.a1_degree.Name = "a1_degree";
            this.a1_degree.Size = new System.Drawing.Size(18, 19);
            this.a1_degree.TabIndex = 6;
            this.a1_degree.Text = "0";
            // 
            // a2_degree
            // 
            this.a2_degree.AutoSize = true;
            this.a2_degree.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.a2_degree.Location = new System.Drawing.Point(119, 31);
            this.a2_degree.Name = "a2_degree";
            this.a2_degree.Size = new System.Drawing.Size(18, 19);
            this.a2_degree.TabIndex = 7;
            this.a2_degree.Text = "0";
            // 
            // a3_degree
            // 
            this.a3_degree.AutoSize = true;
            this.a3_degree.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.a3_degree.Location = new System.Drawing.Point(204, 31);
            this.a3_degree.Name = "a3_degree";
            this.a3_degree.Size = new System.Drawing.Size(18, 19);
            this.a3_degree.TabIndex = 7;
            this.a3_degree.Text = "0";
            // 
            // a4_degree
            // 
            this.a4_degree.AutoSize = true;
            this.a4_degree.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.a4_degree.Location = new System.Drawing.Point(34, 76);
            this.a4_degree.Name = "a4_degree";
            this.a4_degree.Size = new System.Drawing.Size(18, 19);
            this.a4_degree.TabIndex = 8;
            this.a4_degree.Text = "0";
            // 
            // a5_degree
            // 
            this.a5_degree.AutoSize = true;
            this.a5_degree.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.a5_degree.Location = new System.Drawing.Point(119, 76);
            this.a5_degree.Name = "a5_degree";
            this.a5_degree.Size = new System.Drawing.Size(18, 19);
            this.a5_degree.TabIndex = 9;
            this.a5_degree.Text = "0";
            // 
            // a6_degree
            // 
            this.a6_degree.AutoSize = true;
            this.a6_degree.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.a6_degree.Location = new System.Drawing.Point(204, 76);
            this.a6_degree.Name = "a6_degree";
            this.a6_degree.Size = new System.Drawing.Size(18, 19);
            this.a6_degree.TabIndex = 10;
            this.a6_degree.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 功能ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem getToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label_sdk;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem connectToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_cs;
        private System.Windows.Forms.ToolStripMenuItem 模式ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 自動模式ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 手動模式ToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button jog_a1_p;
        private System.Windows.Forms.Button jog_a1_n;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_status;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button jog_home;
        private System.Windows.Forms.Button jog_a6_p;
        private System.Windows.Forms.Button jog_a6_n;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button jog_a5_p;
        private System.Windows.Forms.Button jog_a5_n;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button jog_a4_p;
        private System.Windows.Forms.Button jog_a4_n;
        private System.Windows.Forms.Button jog_a3_p;
        private System.Windows.Forms.Button jog_a3_n;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button jog_a2_p;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button jog_a2_n;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolStripMenuItem disconnectToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label a6_degree;
        private System.Windows.Forms.Label a5_degree;
        private System.Windows.Forms.Label a4_degree;
        private System.Windows.Forms.Label a3_degree;
        private System.Windows.Forms.Label a2_degree;
        private System.Windows.Forms.Label a1_degree;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
    }
}

