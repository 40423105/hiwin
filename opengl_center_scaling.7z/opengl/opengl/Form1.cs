﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SharpGL;

namespace opengl
{
    public partial class Form1 : Form
    {
        double w = 481;
        double h = 400;

        double tx;
        double ty;
        double tz;
        double rx, ry, rz;
        double scale = 1;
        double[] mouse_pos = new double[3] {0.0, 0.0, 0.0};
        double[] point_pos = new double[3] { 0.0, 0.0, 0.0 };
        double[] now = new double[3] { 0.0, 0.0, 0.0 };
        public Form1()
        {
            InitializeComponent();
        }

        private void openGLControl1_OpenGLDraw(object sender, SharpGL.RenderEventArgs args)
        {
            SharpGL.OpenGL gl = this.openGLControl1.OpenGL;
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
 
            gl.LoadIdentity();

            gl.PushMatrix();
            {
                gl.Translate(tx, ty, tz);
                gl.Scale(scale, scale, scale);
                gl.Rotate(rx, 1.0f, 0.0f, 0.0f);
                gl.Rotate(ry, 0.0f, 1.0f, 0.0f);
                gl.Rotate(rz, 0.0f, 0.0f, 1.0f);

                gl.Begin(OpenGL.GL_QUADS);
                {
                    gl.Color(0.0f, 1.0f, 0.0f);            // 顏色改為藍色
                    gl.Vertex(100.0f, 100.0f, -100.0f);          // 四邊形的右上頂點 (頂面)
                    gl.Vertex(-100.0f, 100.0f, -100.0f);         // 四邊形的左上頂點 (頂面)
                    gl.Vertex(-100.0f, 100.0f, 100.0f);          // 四邊形的左下頂點 (頂面)
                    gl.Vertex(100.0f, 100.0f, 100.0f);           // 四邊形的右下頂點 (頂面)

                    gl.Color(1.0f, 0.5f, 0.0f);            // 顏色改成橙色
                    gl.Vertex(100.0f, -100.0f, 100.0f);          // 四邊形的右上頂點(底面)
                    gl.Vertex(-100.0f, -100.0f, 100.0f);         // 四邊形的左上頂點(底面)
                    gl.Vertex(-100.0f, -100.0f, -100.0f);            // 四邊形的左下頂點(底面)
                    gl.Vertex(100.0f, -100.0f, -100.0f);         // 四邊形的右下頂點(底面)

                    gl.Color(100.0f, 0.0f, 0.0f);            // 顏色改成紅色
                    gl.Vertex(100.0f, 100.0f, 100.0f);           // 四邊形的右上頂點(前面)
                    gl.Vertex(-100.0f, 100.0f, 100.0f);          // 四邊形的左上頂點(前面)
                    gl.Vertex(-100.0f, -100.0f, 100.0f);         // 四邊形的左下頂點(前面)
                    gl.Vertex(100.0f, -100.0f, 100.0f);          // 四邊形的右下頂點(前面)

                    gl.Color(1.0f, 1.0f, 0.0f);            // 顏色改成黃色
                    gl.Vertex(100.0f, -100.0f, -100.0f);         // 四邊形的右上頂點(後面)
                    gl.Vertex(-100.0f, -100.0f, -100.0f);            // 四邊形的左上頂點(後面)
                    gl.Vertex(-100.0f, 100.0f, -100.0f);         // 四邊形的左下頂點(後面)
                    gl.Vertex(100.0f, 100.0f, -100.0f);          // 四邊形的右下頂點(後面)



                    gl.Color(0.0f, 0.0f, 1.0f);            // 顏色改成藍色
                    gl.Vertex(-100.0f, 100.0f, 100.0f);          // 四邊形的右上頂點(左面)
                    gl.Vertex(-100.0f, 100.0f, -100.0f);         // 四邊形的左上頂點(左面)
                    gl.Vertex(-100.0f, -100.0f, -100.0f);            // 四邊形的左下頂點(左面)
                    gl.Vertex(-100.0f, -100.0f, 100.0f);         // 四邊形的右下頂點(左面)


                    gl.Color(1.0f, 0.0f, 1.0f);            // 顏色改成紫羅蘭色
                    gl.Vertex(100.0f, 100.0f, -100.0f);          // 四邊形的右上頂點(右面)
                    gl.Vertex(100.0f, 100.0f, 100.0f);           // 四邊形的左上頂點(右面)
                    gl.Vertex(100.0f, -100.0f, 100.0f);          // 四邊形的左下頂點(右面)
                    gl.Vertex(100.0f, -100.0f, -100.0f);            // 四邊形的右下頂點(右面))
                }
                gl.End();
            }
            gl.PopMatrix();
            gl.Flush();


        }

        private void tsmi_front_Click(object sender, EventArgs e)
        {
            rx = -90;
            ry = 0;
            rz = 0;
        }

        private void tsmi_up_Click(object sender, EventArgs e)
        {
            rx = 0;
            ry = 0;
            rz = 0;

        }

        private void tsmi_iso_Click(object sender, EventArgs e)
        {
            rx = -60;
            ry = 0;
            rz = -30;
        }

        private void tsmi_right_Click(object sender, EventArgs e)
        {
            rx = 0;
            ry = -90;
            rz = 0;
        }

        private void openGLControl1_MouseWheel(object sender, MouseEventArgs e)
        {
            mouse_pos = get_unproject(e.X, e.Y);
            point_pos = get_unproject((openGLControl1.Width / 2), openGLControl1.Height / 2);


            if (e.Delta == 120)
            {
                scale += 0.1;
            }
            else if (e.Delta == -120)
            {
                scale -= 0.1;
            }

            tx = (mouse_pos[0] - point_pos[0]) * (1 - scale);
            ty = (mouse_pos[1] - point_pos[1]) * (1 - scale);
            tz = (mouse_pos[2] - point_pos[2]) * (1 - scale);

            Console.WriteLine(scale);
        }

        public  double[] get_unproject(int x , int y)
        {
            OpenGL gl = openGLControl1.OpenGL;

            int[] viewport = new int[4];
            double[] modelview = new double[16];
            double[] projection = new double[16];
            float winX, winY;
            byte[] winZ = new byte[1000];

            double[] pos = new double[3] { 0.0, 0.0, 0.0 };

            gl.GetDouble(OpenGL.GL_MODELVIEW_MATRIX, modelview);
            gl.GetDouble(OpenGL.GL_PROJECTION_MATRIX, projection);
            gl.GetInteger(OpenGL.GL_VIEWPORT, viewport);
            winX = (float)x;
            winY = (float)viewport[3] - (float)y;

            gl.ReadPixels(x, Convert.ToInt16(winY), 1, 1, OpenGL.GL_DEPTH_COMPONENT, OpenGL.GL_FLOAT, winZ);
            gl.UnProject(winX, winY, BitConverter.ToDouble(winZ, 0), modelview, projection, viewport, ref pos[0], ref pos[1], ref pos[2]);

            label1.Text = pos[0].ToString();
            label2.Text = pos[1].ToString();
            label3.Text = pos[2].ToString();

            return pos;
            //https://nehe.gamedev.net/article/using_gluunproject/16013/
        }

        private void openGLControl1_MouseDown(object sender, MouseEventArgs e)
        {
            OpenGL gl = openGLControl1.OpenGL;

            get_unproject(e.X, e.Y);



        }

        private void openGLControl1_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void openGLControl1_OpenGLInitialized(object sender, EventArgs e)
        {
            OpenGL gl = openGLControl1.OpenGL;
            
            gl.Enable(OpenGL.GL_DEPTH_TEST);
            gl.DepthFunc(OpenGL.GL_LEQUAL);
            gl.ClearColor(64.0f / 255.0f, 224.0f / 255.0f, 208.0f / 255.0f, 1.0f);
            
        }

        private void openGLControl1_Resized(object sender, EventArgs e)
        {
            OpenGL gl = openGLControl1.OpenGL;
            gl.Viewport(0, 0, (int)w, (int)h);
            gl.MatrixMode(OpenGL.GL_PROJECTION);
            
            gl.LoadIdentity();
            
            gl.Ortho(-w, w, -h, h, 0.1, 1500);
            gl.MatrixMode(OpenGL.GL_MODELVIEW);
        }
    }
}
