﻿namespace opengl
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.openGLControl1 = new SharpGL.OpenGLControl();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.視角ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_front = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_right = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_up = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_iso = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label_h = new System.Windows.Forms.Label();
            this.label_w = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label_init_z = new System.Windows.Forms.Label();
            this.label_init_y = new System.Windows.Forms.Label();
            this.label_init_x = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label_move_z = new System.Windows.Forms.Label();
            this.label_move_y = new System.Windows.Forms.Label();
            this.label_move_x = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label_rotation_z = new System.Windows.Forms.Label();
            this.label_rotation_y = new System.Windows.Forms.Label();
            this.label_rotation_x = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openGLControl1
            // 
            this.openGLControl1.DrawFPS = true;
            this.openGLControl1.FrameRate = 120;
            this.openGLControl1.Location = new System.Drawing.Point(307, 38);
            this.openGLControl1.Name = "openGLControl1";
            this.openGLControl1.OpenGLVersion = SharpGL.Version.OpenGLVersion.OpenGL2_1;
            this.openGLControl1.RenderContextType = SharpGL.RenderContextType.DIBSection;
            this.openGLControl1.RenderTrigger = SharpGL.RenderTrigger.TimerBased;
            this.openGLControl1.Size = new System.Drawing.Size(481, 400);
            this.openGLControl1.TabIndex = 0;
            this.openGLControl1.OpenGLInitialized += new System.EventHandler(this.openGLControl1_OpenGLInitialized);
            this.openGLControl1.OpenGLDraw += new SharpGL.RenderEventHandler(this.openGLControl1_OpenGLDraw);
            this.openGLControl1.Resized += new System.EventHandler(this.openGLControl1_Resized);
            this.openGLControl1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.openGLControl1_MouseDown);
            this.openGLControl1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.openGLControl1_MouseMove);
            this.openGLControl1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.openGLControl1_MouseUp);
            this.openGLControl1.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.openGLControl1_MouseWheel);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.視角ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 視角ToolStripMenuItem
            // 
            this.視角ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi_front,
            this.tsmi_right,
            this.tsmi_up,
            this.tsmi_iso});
            this.視角ToolStripMenuItem.Name = "視角ToolStripMenuItem";
            this.視角ToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.視角ToolStripMenuItem.Text = "視角";
            // 
            // tsmi_front
            // 
            this.tsmi_front.Name = "tsmi_front";
            this.tsmi_front.Size = new System.Drawing.Size(100, 22);
            this.tsmi_front.Text = "前";
            this.tsmi_front.Click += new System.EventHandler(this.tsmi_front_Click);
            // 
            // tsmi_right
            // 
            this.tsmi_right.Name = "tsmi_right";
            this.tsmi_right.Size = new System.Drawing.Size(100, 22);
            this.tsmi_right.Text = "右";
            this.tsmi_right.Click += new System.EventHandler(this.tsmi_right_Click);
            // 
            // tsmi_up
            // 
            this.tsmi_up.Name = "tsmi_up";
            this.tsmi_up.Size = new System.Drawing.Size(100, 22);
            this.tsmi_up.Text = "上";
            this.tsmi_up.Click += new System.EventHandler(this.tsmi_up_Click);
            // 
            // tsmi_iso
            // 
            this.tsmi_iso.Name = "tsmi_iso";
            this.tsmi_iso.Size = new System.Drawing.Size(100, 22);
            this.tsmi_iso.Text = "等角";
            this.tsmi_iso.Click += new System.EventHandler(this.tsmi_iso_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 426);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 12);
            this.label1.TabIndex = 10;
            this.label1.Text = "screen_h:";
            // 
            // label_h
            // 
            this.label_h.AutoSize = true;
            this.label_h.Location = new System.Drawing.Point(67, 426);
            this.label_h.Name = "label_h";
            this.label_h.Size = new System.Drawing.Size(11, 12);
            this.label_h.TabIndex = 11;
            this.label_h.Text = "0";
            // 
            // label_w
            // 
            this.label_w.AutoSize = true;
            this.label_w.Location = new System.Drawing.Point(67, 401);
            this.label_w.Name = "label_w";
            this.label_w.Size = new System.Drawing.Size(11, 12);
            this.label_w.TabIndex = 12;
            this.label_w.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 401);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 12);
            this.label2.TabIndex = 13;
            this.label2.Text = "screen_w:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 12);
            this.label3.TabIndex = 17;
            this.label3.Text = "init_Z:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 12);
            this.label7.TabIndex = 18;
            this.label7.Text = "init_Y:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 38);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 12);
            this.label8.TabIndex = 19;
            this.label8.Text = "init_X:";
            // 
            // label_init_z
            // 
            this.label_init_z.AutoSize = true;
            this.label_init_z.Location = new System.Drawing.Point(61, 87);
            this.label_init_z.Name = "label_init_z";
            this.label_init_z.Size = new System.Drawing.Size(11, 12);
            this.label_init_z.TabIndex = 14;
            this.label_init_z.Text = "0";
            // 
            // label_init_y
            // 
            this.label_init_y.AutoSize = true;
            this.label_init_y.Location = new System.Drawing.Point(61, 62);
            this.label_init_y.Name = "label_init_y";
            this.label_init_y.Size = new System.Drawing.Size(11, 12);
            this.label_init_y.TabIndex = 15;
            this.label_init_y.Text = "0";
            // 
            // label_init_x
            // 
            this.label_init_x.AutoSize = true;
            this.label_init_x.Location = new System.Drawing.Point(61, 38);
            this.label_init_x.Name = "label_init_x";
            this.label_init_x.Size = new System.Drawing.Size(11, 12);
            this.label_init_x.TabIndex = 16;
            this.label_init_x.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 171);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 12);
            this.label9.TabIndex = 24;
            this.label9.Text = "move_Z:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 146);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 12);
            this.label10.TabIndex = 25;
            this.label10.Text = "move_Y:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 122);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 12);
            this.label11.TabIndex = 26;
            this.label11.Text = "move_X:";
            // 
            // label_move_z
            // 
            this.label_move_z.AutoSize = true;
            this.label_move_z.Location = new System.Drawing.Point(65, 171);
            this.label_move_z.Name = "label_move_z";
            this.label_move_z.Size = new System.Drawing.Size(11, 12);
            this.label_move_z.TabIndex = 21;
            this.label_move_z.Text = "0";
            // 
            // label_move_y
            // 
            this.label_move_y.AutoSize = true;
            this.label_move_y.Location = new System.Drawing.Point(65, 146);
            this.label_move_y.Name = "label_move_y";
            this.label_move_y.Size = new System.Drawing.Size(11, 12);
            this.label_move_y.TabIndex = 22;
            this.label_move_y.Text = "0";
            // 
            // label_move_x
            // 
            this.label_move_x.AutoSize = true;
            this.label_move_x.Location = new System.Drawing.Point(65, 122);
            this.label_move_x.Name = "label_move_x";
            this.label_move_x.Size = new System.Drawing.Size(11, 12);
            this.label_move_x.TabIndex = 23;
            this.label_move_x.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 260);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 12);
            this.label4.TabIndex = 30;
            this.label4.Text = "rotation_Z:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 235);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 12);
            this.label5.TabIndex = 31;
            this.label5.Text = "rotation_Y:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 211);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 12);
            this.label6.TabIndex = 32;
            this.label6.Text = "rotation_X:";
            // 
            // label_rotation_z
            // 
            this.label_rotation_z.AutoSize = true;
            this.label_rotation_z.Location = new System.Drawing.Point(79, 260);
            this.label_rotation_z.Name = "label_rotation_z";
            this.label_rotation_z.Size = new System.Drawing.Size(11, 12);
            this.label_rotation_z.TabIndex = 27;
            this.label_rotation_z.Text = "0";
            // 
            // label_rotation_y
            // 
            this.label_rotation_y.AutoSize = true;
            this.label_rotation_y.Location = new System.Drawing.Point(79, 235);
            this.label_rotation_y.Name = "label_rotation_y";
            this.label_rotation_y.Size = new System.Drawing.Size(11, 12);
            this.label_rotation_y.TabIndex = 28;
            this.label_rotation_y.Text = "0";
            // 
            // label_rotation_x
            // 
            this.label_rotation_x.AutoSize = true;
            this.label_rotation_x.Location = new System.Drawing.Point(79, 211);
            this.label_rotation_x.Name = "label_rotation_x";
            this.label_rotation_x.Size = new System.Drawing.Size(11, 12);
            this.label_rotation_x.TabIndex = 29;
            this.label_rotation_x.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label_rotation_z);
            this.Controls.Add(this.label_rotation_y);
            this.Controls.Add(this.label_rotation_x);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label_move_z);
            this.Controls.Add(this.label_move_y);
            this.Controls.Add(this.label_move_x);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label_init_z);
            this.Controls.Add(this.label_init_y);
            this.Controls.Add(this.label_init_x);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label_h);
            this.Controls.Add(this.label_w);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.openGLControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SharpGL.OpenGLControl openGLControl1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 視角ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmi_front;
        private System.Windows.Forms.ToolStripMenuItem tsmi_right;
        private System.Windows.Forms.ToolStripMenuItem tsmi_up;
        private System.Windows.Forms.ToolStripMenuItem tsmi_iso;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_h;
        private System.Windows.Forms.Label label_w;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label_init_z;
        private System.Windows.Forms.Label label_init_y;
        private System.Windows.Forms.Label label_init_x;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label_move_z;
        private System.Windows.Forms.Label label_move_y;
        private System.Windows.Forms.Label label_move_x;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label_rotation_z;
        private System.Windows.Forms.Label label_rotation_y;
        private System.Windows.Forms.Label label_rotation_x;
    }
}

