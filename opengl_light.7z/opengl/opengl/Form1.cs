﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SharpGL;

namespace opengl
{
    public partial class Form1 : Form
    {
        double w;
        double h;
        double program_w;
        double program_h;
        double scale_w;
        double scale_h;

        double tx;
        double ty;
        double tz;
        double rx, ry, rz;
        double scale = 1;

        bool move = false;
        bool rotation = false;
        bool right = false;
        double[] inital_pos = new double[3] { 0.0, 0.0, 0.0 };
        double[] move_pos = new double[3] { 0.0, 0.0, 0.0 };
        double[] old_move_pos = new double[3] { 0.0, 0.0, 0.0 };
        double[] old_rotation_angle = new double[3] { 0.0, 0.0, 0.0 };
        double[] mouse_pos = new double[3] { 0.0, 0.0, 0.0 };
        double[] point_pos = new double[3] { 0.0, 0.0, 0.0 };
        public Form1()
        {
            InitializeComponent();
        }

        private void Draw_cone()
        {
            double cone_radius = 100;
            double cone_h = 200;
            int offset_x = 300;
            SharpGL.OpenGL gl = this.openGLControl1.OpenGL;
            gl.PushName(2);
            gl.PushMatrix();
            {
                gl.Translate(offset_x, 0, 0);
                gl.Begin(OpenGL.GL_TRIANGLE_FAN);
                {
                    gl.Color(0.6f, 0.2f, 0.4f);
                    gl.Vertex(0, 0, cone_h);
                    for (int cone_angle = 0; cone_angle < 360; cone_angle++)
                    {
                        gl.Vertex(Math.Sin(cone_angle) * cone_radius, Math.Cos(cone_angle) * cone_radius, 0);
                    }
                    gl.End();
                }

                gl.PopName();
                gl.PopMatrix();
            }
        }
        private void SLight()
        {
            SharpGL.OpenGL gl = openGLControl1.OpenGL;
            float[] whitecolor = { 1.0f, 1.0f, 1.0f, 1.0f };
            float[] positionz = { 0.0f, 0.0f, 1.0f, 0.0f };
            float[] positiony = { 0.0f, 1.0f, 0.0f, 0.0f };
            float[] positionx = { 1.0f, 0.0f, 0.0f, 0.0f };
            // setup lighting
            //===================================================
            gl.PushMatrix();
            {
 
                gl.Light(OpenGL.GL_LIGHT0, OpenGL.GL_POSITION, positionz);
                gl.Light(OpenGL.GL_LIGHT0, OpenGL.GL_AMBIENT, whitecolor);
                gl.Light(OpenGL.GL_LIGHT0, OpenGL.GL_DIFFUSE, whitecolor);
                gl.Light(OpenGL.GL_LIGHT0, OpenGL.GL_SPECULAR, whitecolor);

                gl.Light(OpenGL.GL_LIGHT1, OpenGL.GL_POSITION, positiony);
                gl.Light(OpenGL.GL_LIGHT1, OpenGL.GL_AMBIENT, whitecolor);
                gl.Light(OpenGL.GL_LIGHT1, OpenGL.GL_DIFFUSE, whitecolor);
                gl.Light(OpenGL.GL_LIGHT1, OpenGL.GL_SPECULAR, whitecolor);

                gl.Light(OpenGL.GL_LIGHT2, OpenGL.GL_POSITION, positionx);
                gl.Light(OpenGL.GL_LIGHT2, OpenGL.GL_AMBIENT, whitecolor);
                gl.Light(OpenGL.GL_LIGHT2, OpenGL.GL_DIFFUSE, whitecolor);
                gl.Light(OpenGL.GL_LIGHT2, OpenGL.GL_SPECULAR, whitecolor);

                gl.Enable(OpenGL.GL_LIGHTING);
                gl.Enable(OpenGL.GL_LIGHT0);
                gl.Enable(OpenGL.GL_LIGHT1);
                gl.Enable(OpenGL.GL_LIGHT2);
                gl.PopMatrix();
            }
        }

        private void openGLControl1_OpenGLDraw(object sender, SharpGL.RenderEventArgs args)
        {
            SharpGL.OpenGL gl = this.openGLControl1.OpenGL;
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT | OpenGL.GL_STENCIL_BUFFER_BIT);
            
            gl.LoadIdentity();
            
            gl.Scale(scale, scale, scale);
            SLight();
            gl.PushName(0);
            gl.PushMatrix();
            {
                
                gl.Translate(tx, ty, tz);
                gl.Rotate(rx, 1.0f, 0.0f, 0.0f);
                gl.Rotate(ry, 0.0f, 1.0f, 0.0f);
                gl.Rotate(rz, 0.0f, 0.0f, 1.0f);

                gl.Begin(OpenGL.GL_QUADS);
                {
                    gl.Color(0.0f, 1.0f, 0.0f);            // 顏色改為藍色
                    gl.Vertex(100.0f, 100.0f, 0.0f);          // 四邊形的右上頂點 (頂面)
                    gl.Vertex(-100.0f, 100.0f, 0.0f);         // 四邊形的左上頂點 (頂面)
                    gl.Vertex(-100.0f, 100.0f, 200.0f);          // 四邊形的左下頂點 (頂面)
                    gl.Vertex(100.0f, 100.0f, 200.0f);           // 四邊形的右下頂點 (頂面)

                    gl.Color(1.0f, 0.5f, 0.0f);            // 顏色改成橙色
                    gl.Vertex(100.0f, -100.0f, 200.0f);          // 四邊形的右上頂點(底面)
                    gl.Vertex(-100.0f, -100.0f, 200.0f);         // 四邊形的左上頂點(底面)
                    gl.Vertex(-100.0f, -100.0f, 0.0f);            // 四邊形的左下頂點(底面)
                    gl.Vertex(100.0f, -100.0f, 0.0f);         // 四邊形的右下頂點(底面)

                    gl.Color(100.0f, 0.0f, 0.0f);            // 顏色改成紅色
                    gl.Vertex(100.0f, 100.0f, 200.0f);           // 四邊形的右上頂點(前面)
                    gl.Vertex(-100.0f, 100.0f,200.0f);          // 四邊形的左上頂點(前面)
                    gl.Vertex(-100.0f, -100.0f, 200.0f);         // 四邊形的左下頂點(前面)
                    gl.Vertex(100.0f, -100.0f, 200.0f);          // 四邊形的右下頂點(前面)

                    gl.Color(1.0f, 1.0f, 0.0f);            // 顏色改成黃色
                    gl.Vertex(100.0f, -100.0f, 0.0f);         // 四邊形的右上頂點(後面)
                    gl.Vertex(-100.0f, -100.0f, 0.0f);            // 四邊形的左上頂點(後面)
                    gl.Vertex(-100.0f, 100.0f, 0.0f);         // 四邊形的左下頂點(後面)
                    gl.Vertex(100.0f, 100.0f, 0.0f);          // 四邊形的右下頂點(後面)

                    gl.Color(0.0f, 0.0f, 1.0f);            // 顏色改成藍色
                    gl.Vertex(-100.0f, 100.0f, 200.0f);          // 四邊形的右上頂點(左面)
                    gl.Vertex(-100.0f, 100.0f, 0.0f);         // 四邊形的左上頂點(左面)
                    gl.Vertex(-100.0f, -100.0f, 0.0f);            // 四邊形的左下頂點(左面)
                    gl.Vertex(-100.0f, -100.0f, 200.0f);         // 四邊形的右下頂點(左面)

                    gl.Color(1.0f, 0.0f, 1.0f);            // 顏色改成紫羅蘭色
                    gl.Vertex(100.0f, 100.0f, 0.0f);          // 四邊形的右上頂點(右面)
                    gl.Vertex(100.0f, 100.0f, 200.0f);           // 四邊形的左上頂點(右面)
                    gl.Vertex(100.0f, -100.0f, 200.0f);          // 四邊形的左下頂點(右面)
                    gl.Vertex(100.0f, -100.0f, 0.0f);            // 四邊形的右下頂點(右面))
                }
                gl.End();
            }
            gl.PopName();
            gl.PopMatrix();
            gl.Flush();
        }

        private void tsmi_front_Click(object sender, EventArgs e)
        {
            right = false;
            rx = -90;
            ry = 0;
            rz = 0;
            old_rotation_angle[0] = rz;
            old_rotation_angle[1] = rx;
        }

        private void tsmi_up_Click(object sender, EventArgs e)
        {
            right = false;
            rx = 0;
            ry = 0;
            rz = 0;
            old_rotation_angle[0] = rz;
            old_rotation_angle[1] = rx;

        }

        private void tsmi_iso_Click(object sender, EventArgs e)
        {
            right = false;
            rx = -60;            
            ry = 0;           
            rz = -30;
            old_rotation_angle[0] = rz;
            old_rotation_angle[1] = rx;
        }

        private void tsmi_right_Click(object sender, EventArgs e)
        {
            right = true;
            rx = 0;
            ry = -90;
            rz = 0;
            old_rotation_angle[1] = rz;
            old_rotation_angle[0] = ry;

        }

        private void openGLControl1_MouseWheel(object sender, MouseEventArgs e)
        {
            mouse_pos = get_unproject(e.X, e.Y);
            point_pos = get_unproject((openGLControl1.Width / 2), openGLControl1.Height / 2);


            if (e.Delta == 120)
            {
                scale += 0.1;
            }
            else if (e.Delta == -120)
            {
                scale -= 0.1;
            }

            tx = (mouse_pos[0] - point_pos[0]) * (1 - scale);
            ty = (mouse_pos[1] - point_pos[1]) * (1 - scale);
            tz = (mouse_pos[2] - point_pos[2]) * (1 - scale);

            Console.WriteLine(scale);
        }

        public  double[] get_unproject(int x , int y)
        {
            OpenGL gl = openGLControl1.OpenGL;

            int[] viewport = new int[4];
            double[] modelview = new double[16];
            double[] projection = new double[16];
            float winX, winY;
            byte[] winZ = new byte[1000];

            double[] pos = new double[3] { 0.0, 0.0, 0.0 };

            gl.GetDouble(OpenGL.GL_MODELVIEW_MATRIX, modelview);
            gl.GetDouble(OpenGL.GL_PROJECTION_MATRIX, projection);
            gl.GetInteger(OpenGL.GL_VIEWPORT, viewport);
            winX = (float)x;
            winY = (float)viewport[3] - (float)y;

            gl.ReadPixels(x, Convert.ToInt16(winY), 1, 1, OpenGL.GL_DEPTH_COMPONENT, OpenGL.GL_FLOAT, winZ);
            gl.UnProject(winX, winY, BitConverter.ToDouble(winZ, 0), modelview, projection, viewport, ref pos[0], ref pos[1], ref pos[2]);

            return pos;
            //https://nehe.gamedev.net/article/using_gluunproject/16013/
        }

        private void openGLControl1_MouseDown(object sender, MouseEventArgs e)
        {
            OpenGL gl = openGLControl1.OpenGL;

            inital_pos = get_unproject(e.X, e.Y);
            label_init_x.Text = inital_pos[0].ToString();
            label_init_y.Text = inital_pos[1].ToString();
            label_init_z.Text = inital_pos[2].ToString();

            if(move == false && rotation == false)
            {
                switch(e.Button)
                {
                    case MouseButtons.Left:
                        move = true;
                        break;
                    case MouseButtons.Right:
                        rotation = true;
                        break;
                    default:
                        break;
                }
                
            }           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            program_w = this.Size.Width;
            program_h = this.Size.Height;
            scale_w = program_w - w;
            scale_h = program_h - h;
        }

        private void openGLControl1_MouseMove(object sender, MouseEventArgs e)
        {

            if (move == true)
            {
                move_pos = get_unproject(e.X, e.Y);
                tx = Math.Round((move_pos[0] - inital_pos[0]) + old_move_pos[0], 3);
                ty = Math.Round((move_pos[1] - inital_pos[1]) + old_move_pos[1], 3);
                tz = Math.Round((move_pos[2] - inital_pos[2]) + old_move_pos[2], 3);
                label_move_x.Text = tx.ToString();
                label_move_y.Text = ty.ToString();
                label_move_z.Text = tz.ToString();
            }else if(rotation == true && right == false)
            {
                move_pos = get_unproject(e.X, e.Y);
                rx =  Math.Round(-(move_pos[1] - inital_pos[1]) + old_rotation_angle[1], 3);
                rz =  Math.Round((move_pos[0] - inital_pos[0]) + old_rotation_angle[0], 3);
                label_rotation_x.Text = rx.ToString();
                label_rotation_y.Text = ry.ToString();
                label_rotation_z.Text = rz.ToString();
            }else if (rotation == true && right == true)
            {
                move_pos = get_unproject(e.X, e.Y);
                ry = Math.Round((move_pos[0] - inital_pos[0]) + old_rotation_angle[0], 3);
                rz = Math.Round((move_pos[1] - inital_pos[1]) + old_rotation_angle[1], 3);
                label_rotation_x.Text = rx.ToString();
                label_rotation_y.Text = ry.ToString();
                label_rotation_z.Text = rz.ToString();
            }


        }

        private void openGLControl1_MouseUp(object sender, MouseEventArgs e)
        {
            move = false;
            rotation = false;
            old_move_pos[0] = tx;
            old_move_pos[1] = ty;
            old_move_pos[2] = tz;

            old_rotation_angle[0] = rz;
            old_rotation_angle[1] = rx;
            if(right == true)
            {
                old_rotation_angle[0] = ry;
                old_rotation_angle[1] = rz;
            }
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            program_w = this.Size.Width;
            program_h = this.Size.Height;
            h = program_h - scale_h;
            w = program_w - scale_w;
            label_w.Text = w.ToString();
            label_h.Text = h.ToString();
            openGLControl1.Size = new Size((int)w, (int)h);
        }

        private void openGLControl1_OpenGLInitialized(object sender, EventArgs e)
        {
            OpenGL gl = openGLControl1.OpenGL;
            gl.Enable(OpenGL.GL_DEPTH_TEST);
            gl.Enable(OpenGL.GL_COLOR_MATERIAL);
            gl.DepthFunc(OpenGL.GL_LEQUAL);
            gl.ClearColor(153.0f / 255.0f, 204.0f / 255.0f, 255.0f / 255.0f, 1.0f);
        }

        private void openGLControl1_Resized(object sender, EventArgs e)
        {
            OpenGL gl = openGLControl1.OpenGL;

            w = openGLControl1.Size.Width;
            h = openGLControl1.Size.Height;
            label_w.Text = w.ToString();
            label_h.Text = h.ToString();
            gl.ShadeModel(OpenGL.GL_SMOOTH);
            gl.Viewport(0, 0, (int)w, (int)h);
            gl.MatrixMode(OpenGL.GL_PROJECTION);
            
            gl.LoadIdentity();
     
            gl.Ortho(-w, w, -h, h, -1500, 1500);
            gl.MatrixMode(OpenGL.GL_MODELVIEW);
        }
    }
}
